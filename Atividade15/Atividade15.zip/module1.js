const message = 'Mensagem que vem do módulo';

module.exports = message;